# -*- coding: utf-8 -*-

from . import mail_activity
from . import ir_attachment
from . import document
from . import documents_mixin
from . import folder
from . import res_partner
from . import share
from . import tags
from . import workflow
