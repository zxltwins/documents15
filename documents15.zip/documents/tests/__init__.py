# -*- coding: utf-8 -*-

from . import test_documents
from . import test_tags
from . import test_security
