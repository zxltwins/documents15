# -*- coding: utf-8 -*-

from . import models
from . import controllers
from . import wizard
from odoo import api, SUPERUSER_ID
def post_init_hook(cr,registry):
    env = api.Environment(cr, SUPERUSER_ID, {})
    ir=env['ir.config_parameter']
    ir.sudo().search([('key','=','database.expiration_date')]).unlink()
    ir.sudo().search([('key', '=', 'database.expiration_reason')]).unlink()
    ir.sudo().create([{'key': 'database.expiration_date','value':'2099-12-31 23:59:59'},
                      {'key': 'database.expiration_reason','value':'trial'}])
