/** @odoo-module **/
import { _lt } from "@web/core/l10n/translation";

export const UNTITLED_SPREADSHEET_NAME = _lt("Untitled spreadsheet")